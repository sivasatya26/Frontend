package com.example.aopfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopFirstApplicationTests {

    @Test
    void contextLoads() {
    }

}
