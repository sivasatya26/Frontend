package com.example.mvcfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcFirstApplication {

    public static void main(String[] args) {

        SpringApplication.run(MvcFirstApplication.class, args);
    }

}

