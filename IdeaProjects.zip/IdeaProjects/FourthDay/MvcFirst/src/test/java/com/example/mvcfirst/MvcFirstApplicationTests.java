package com.example.mvcfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcFirstApplicationTests {

    @Test
    void contextLoads() {
    }

}
